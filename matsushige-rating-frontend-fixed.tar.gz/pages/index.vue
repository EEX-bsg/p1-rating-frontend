<template>
  <v-container fluid class="fill-height">
    <v-row justify="center" align="center">
      <v-col cols="12" sm="8" md="6" lg="4">
        <v-card class="pa-6" elevation="2">
          <v-card-title class="text-h5 text-center mb-4">
            まつしげレーティング
          </v-card-title>
          
          <v-card-subtitle class="text-center mb-6">
            プレイヤーIDを入力してください
          </v-card-subtitle>

          <v-autocomplete
            v-model="selectedPlayer"
            :items="playerSuggestions"
            :loading="isLoadingSuggestions"
            label="プレイヤーID"
            placeholder="名前を入力"
            clearable
            autofocus
            variant="outlined"
            @update:search="onSearchUpdate"
            @keydown.enter="handleSubmit"
          />

          <v-btn
            block
            color="primary"
            size="large"
            :disabled="!selectedPlayer"
            @click="handleSubmit"
          >
            決定
          </v-btn>

          <v-divider class="my-4" />

          <div class="text-caption text-center text-medium-emphasis">
            <div v-if="lastDbUpdate">
              DB最終更新: {{ formatTimestamp(lastDbUpdate) }}
            </div>
            <div v-if="lastFetchTime">
              最終取得: {{ formatTimestamp(lastFetchTime) }}
            </div>
          </div>
        </v-card>
      </v-col>
    </v-row>
  </v-container>
</template>

<script setup lang="ts">
import { useAppStore } from '~/stores/app'

const store = useAppStore()
const api = useApi()
const router = useRouter()

const selectedPlayer = ref<string | null>(null)
const playerSuggestions = ref<string[]>([])
const isLoadingSuggestions = ref(false)
const lastDbUpdate = computed(() => store.lastDbUpdate)
const lastFetchTime = computed(() => store.lastFetchTime ? new Date(store.lastFetchTime).toISOString() : null)

const formatTimestamp = (ts: string | number) => {
  const date = new Date(ts)
  return date.toLocaleString('ja-JP')
}

const loadSuggestions = async () => {
  if (store.isCacheValid && store.playerCache.length > 0) {
    playerSuggestions.value = store.playerCache
    return
  }

  isLoadingSuggestions.value = true
  try {
    const result = await api.getSuggest('', 100)
    playerSuggestions.value = result.candidates || []
    store.setPlayerCache(playerSuggestions.value)
    store.setLastFetchTime()
  } catch (error) {
    console.error('Failed to load suggestions:', error)
  } finally {
    isLoadingSuggestions.value = false
  }
}

const onSearchUpdate = (value: string) => {
  // 既にキャッシュがあれば、それでフィルタリング
  if (store.playerCache.length > 0) {
    if (value) {
      playerSuggestions.value = store.playerCache.filter(p => 
        p.toLowerCase().includes(value.toLowerCase())
      )
    } else {
      playerSuggestions.value = store.playerCache
    }
  }
}

const handleSubmit = () => {
  if (selectedPlayer.value) {
    store.setPlayerId(selectedPlayer.value)
    router.push('/main')
  }
}

const fetchMeta = async () => {
  try {
    const meta = await api.getMeta()
    if (meta.lastUpdatedAt) {
      store.setLastDbUpdate(meta.lastUpdatedAt)
    }
  } catch (error) {
    console.error('Failed to fetch meta:', error)
  }
}

onMounted(() => {
  loadSuggestions()
  fetchMeta()
})
</script>
